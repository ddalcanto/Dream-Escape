package dreamEscapeLauncher;

public class Launcher {

	public static void main(String[] args) {
		Game program = new Game();
		program.run();
	}
}
