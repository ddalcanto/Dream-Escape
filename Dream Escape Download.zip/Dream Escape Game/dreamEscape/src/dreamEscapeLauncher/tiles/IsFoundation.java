package dreamEscapeLauncher.tiles;

public interface IsFoundation {
	// The width and height of the foundation type tiles.
	int tileWidth = 32;
	int tileHeight = 32;
}
