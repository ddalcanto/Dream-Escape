package dreamEscapeLauncher.world;

public interface WorldImage {

	abstract void loadImage();
}
